## Resultat de cette journee

## Fichiers et decisions

## Verification
- Commande executee :
- Resultat observe :
- Rapport et configuration :

## Limites et points ouverts

## Journal
- [ ] La journee correspondante est renseignee.
- [ ] La conclusion reste dans le perimetre du modele.
