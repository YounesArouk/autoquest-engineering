# E-City : guide méthodique, jour par jour et GitHub

Préparation de 20 jours, du 23 octobre au 11 novembre 2026.

## Un résultat vérifié et publié chaque jour

Ce guide accompagne le cours de 106 pages ; le kit fournit la base de calcul.

Ton objectif est de construire **E-City : conception et validation virtuelle d’un véhicule électrique urbain**. Le résultat final sera un dépôt comprenant besoin, hypothèses, modèles, exigences, architecture, interfaces, configuration, risques, essais et décision de concept. Chaque journée ajoute une pièce réelle au dossier.

| Ce qui est fourni | Ce que tu produis personnellement |
| --- | --- |
| Kit Python | Tu exécutes, vérifies et interprètes les modèles ; tu modifies les paramètres avec une trace. |
| Documents modèles | Tu complètes les champs A_COMPLETER avec tes calculs, choix, sources et preuves. |
| Guide GitHub | Tu crées ton dépôt, publies tes commits et relis tes pull requests. |
| Valeurs de référence | Tu les retrouves puis explores les conditions où elles changent. |

Ce cycle est repris chaque jour pour relier apprentissage et pratique.

### Rythme

Prévois environ 2 h : 20 min de lecture, 60 min de réalisation, 20 min de contrôle, 20 min de journal et publication. La journée 1 peut demander davantage si les outils ne sont pas installés.

Les journées sont alignées sur le cours : **23 octobre au 11 novembre 2026**, avant l’entretien du 12 novembre. Si tu démarres plus tard, garde l’ordre ; la priorité est une preuve compréhensible, puis une extension.

### Portée

Les calculs restent synthétiques. La base Python est fournie ; les analyses et le journal doivent refléter ce que tu as effectivement fait. Le dépôt initial et les futurs tags ne signifient pas validation physique du véhicule.

## Installer Git et Python, puis extraire le kit

Toutes les commandes du guide sont pour CMD sous Windows.

**1.** Installe Git for Windows si **git --version** n’est pas reconnu. Conserve Git Credential Manager pendant l’installation. Pour Python, utilise une version 3.10 ou plus récente. Ferme puis rouvre le terminal après une installation.

**2.** Extrais E_City_Kit_Demarrage_GitHub.zip. Place le dossier intérieur **E-City** dans Documents. Il doit contenir README.md, ecity, tools, tests et config ; évite un niveau E-City/E-City créé par une extraction mal placée.

```bat
cd /d "%USERPROFILE%\Documents\E-City"
git --version
py --version
py -m unittest discover -s tests -v
```

**3.** Si py n’existe pas mais python fonctionne, utilise **python** à la place de **py** partout. Aucun pip, environnement virtuel ou bibliothèque externe n’est nécessaire pour ce kit.

| Contrôle | Résultat attendu |
| --- | --- |
| Emplacement | dir affiche README.md et les dossiers du kit. |
| Tests | 12 tests, puis OK. Un échec bloque l’interprétation du modèle concerné. |
| Édition | Un éditeur texte sauvegarde .md, .json et .py avec leur vraie extension en UTF-8. |

**4.** Lis config/reference.json sans le changer : masse 1 200 kg, batterie 26 kWh, fenêtre utile 0,8, rapport 9. Le signe décimal JSON est un point. Un pourcentage de 80 % devient 0.8, pas 80.

### Adresses officielles

Git : https://git-scm.com/downloads/win
Python : https://www.python.org/downloads/windows/
Si tes outils sont déjà installés et les tests passent, continue directement.

## Créer le dépôt vide et publier le kit

Ces opérations sont à exécuter sur ton ordinateur et ton compte.

**À exécuter une seule fois, à la fin de J1**, après avoir complété le cadrage et journal/day01.md. Sur GitHub, crée un repository E-City vide. Choisis Private ou Public selon l’audience voulue. Laisse décochés README, .gitignore et licence, déjà préparés localement pour les premiers fichiers.

**2.** Dans CMD, à la racine du kit, initialise le dépôt. Remplace EMAIL_GITHUB par ton adresse de commit ou ton adresse noreply GitHub et VOTRE_LOGIN par ton identifiant réel. Les réglages ci-dessous sont locaux à E-City.

```bat
git init -b main
git config user.name "Younes AROUK"
git config user.email "EMAIL_GITHUB"
git status --short
git add .
git diff --cached --stat
git commit -m "chore: initialise E-City learning project"
git remote add origin https://github.com/VOTRE_LOGIN/E-City.git
git remote -v
git push -u origin main
```

**3.** Si une fenêtre de connexion s’ouvre, connecte-toi au compte propriétaire du dépôt. Git Credential Manager gère l’authentification HTTPS selon ta configuration. Le mot de passe du compte GitHub n’est pas un mot de passe Git à saisir comme anciennement.

### Vérification

Recharge la page du dépôt : le README et les dossiers doivent apparaître. git status doit indiquer un arbre propre. git log --oneline -1 affiche ton premier commit.

Le git add . initial concerne le kit que tu viens d’extraire : relis toujours le résumé et la liste. Les journées suivantes utilisent des chemins précis. Garde les informations confidentielles, les clés et les documents internes hors du dépôt.

## Commencer et terminer une journée

De J2 à J20 : une branche par journée, issue de main à jour.

Au début : exemple du jour 2

```bat
cd /d "%USERPROFILE%\Documents\E-City"
git status
git switch main
git pull --ff-only
git switch -c jour-02
```

La PR de la veille doit être fusionnée avant de créer la branche suivante. Si tu as déjà créé jour-02 et reprends ce travail, utilise **git switch jour-02** ; ne recrée pas la branche. Si des modifications locales restent présentes, termine ou sauvegarde ton travail avant de changer de sujet.

Après le travail : exemple du jour 2

```bat
py -m unittest discover -s tests -v
git add docs/02_dimensionnement.md reports/day02 journal/day02.md
git diff --cached --stat
git diff --cached
git commit -m "feat: document traction sizing and gear ratio"
git push -u origin jour-02
```

| Commande | Sens |
| --- | --- |
| add | Sélectionner ce qui entrera dans le prochain commit. |
| diff --cached | Relire exactement la sélection. |
| commit | Créer un point d’historique local avec un message. |
| push | Envoyer la branche et ses commits sur GitHub. |

### Puis

Crée, relis et fusionne la pull request sur GitHub selon la page suivante. Après fusion : git switch main puis git pull --ff-only. Remplace 02 par le numéro de la journée suivante.

## Relire puis fusionner sa contribution

Push et fusion sont deux étapes différentes.

**1.** Sur ton dépôt GitHub, sélectionne la branche jour-NN ou utilise Compare & pull request. Vérifie **base = main** et **compare = jour-NN**. Les fichiers modifiés doivent correspondre à la journée.

**2.** Donne un titre utile, par exemple « J02 - Dimensionnement traction ». Le modèle de PR fourni dans .github prépare les rubriques suivantes.

| Rubrique | À écrire |
| --- | --- |
| Résultat | Le problème traité et la décision provisoire. |
| Fichiers | Les documents, paramètres et résultats concernés. |
| Vérification | Commandes réellement exécutées et résultat obtenu. |
| Limites | Hypothèses, cas défavorables et preuves ouvertes. |
| Journal | Lien vers journal/dayNN.md complété. |

**3.** Relis Files changed, les valeurs et les liens. Le kit ne configure pas GitHub Actions : il n’y a donc pas de test automatique distant à inventer dans ta description. Inscris les tests locaux que tu as exécutés.

**4.** Si la PR est prête, fusionne-la, puis récupère main sur ton PC. Le merge commit conserve facilement l’historique des journées. Une auto-revue n’est pas une revue indépendante ; indique ton mode de vérification avec honnêteté.

```bat
git switch main
git pull --ff-only
git log --oneline --graph -8
git status
```

### Si tu corriges avant fusion

Reste sur la même branche, modifie les fichiers, refais les vérifications, crée un nouveau commit puis git push. La même PR sera mise à jour. Une PR fermée sans fusion n’ajoute rien à main.

## Jours 1 à 10 : quoi construire

Chaque ligne devient une contribution vérifiée puis publiée.

| Jour / date | Réalisation | Lecture associée |
| --- | --- | --- |
| 01 · 23/10 | Installer le projet et publier le premier commit | Cours p. 2-9 |
| 02 · 24/10 | Dimensionner la traction sur le plat et en pente | Cours p. 9-12 et 18 |
| 03 · 25/10 | Étudier énergie, autonomie et distance d’arrêt | Cours p. 13-17 |
| 04 · 26/10 | Écrire huit exigences et leurs preuves | Cours p. 19 et 75 |
| 05 · 27/10 | Allouer les fonctions et fixer les interfaces | Cours p. 20-27 et 76 |
| 06 · 28/10 | Créer une baseline et étudier un changement | Cours p. 28-30 et 33 |
| 07 · 29/10 | Relier nomenclature et industrialisation | Cours p. 29-32 et 43 |
| 08 · 30/10 | Piloter le travail et les risques | Cours p. 34-39 |
| 09 · 31/10 | Travailler comme responsable composant | Cours p. 40-44 |
| 10 · 01/11 | Décrire l’ECU et la chaîne de mesure | Cours p. 45-48 |

### Lecture

Les numéros de page renvoient au cours Formation Automobile / Projet E-City de 106 pages. Ce guide explique les actions à réaliser ; le cours explique les concepts.

N’avance pas uniquement parce que les fichiers existent : les modèles de documents portent A_COMPLETER. Remplace-les par ton raisonnement et tes preuves, en gardant les points inconnus explicitement ouverts.

## Jours 11 à 20 : quoi construire

Chaque ligne devient une contribution vérifiée puis publiée.

| Jour / date | Réalisation | Lecture associée |
| --- | --- | --- |
| 11 · 02/11 | Simuler messages, codage et timeout | Cours p. 49-51 et 55 |
| 12 · 03/11 | Organiser états, logiciel et compatibilités | Cours p. 23, 52-54 |
| 13 · 04/11 | Analyser dangers, défaillances et limites | Cours p. 56-58 |
| 14 · 05/11 | Relier cyber, qualité et plan d’essais | Cours p. 59-64 |
| 15 · 06/11 | Comparer coûts et fournisseurs | Cours p. 65-69 |
| 16 · 07/11 | Rendre les données interprétables | Cours p. 70-73 |
| 17 · 08/11 | Assembler la synthèse intégrée | Cours p. 74-80 |
| 18 · 09/11 | Exécuter une campagne et propager un changement | Cours p. 77-79 et 83-85 |
| 19 · 10/11 | Vérifier depuis un clone neuf et s’entraîner | Cours p. 80 et 86-90 |
| 20 · 11/11 | Finaliser la version de portfolio | Cours p. 91 |

### Lecture

Les numéros de page renvoient au cours Formation Automobile / Projet E-City de 106 pages. Ce guide explique les actions à réaliser ; le cours explique les concepts.

N’avance pas uniquement parce que les fichiers existent : les modèles de documents portent A_COMPLETER. Remplace-les par ton raisonnement et tes preuves, en gardant les points inconnus explicitement ouverts.

## Quel fichier modifier et où ranger la preuve ?

Les dossiers gardent le même rôle pendant les vingt journées.

| Emplacement | Rôle | À faire |
| --- | --- | --- |
| README.md | Entrée de portfolio | Mettre à jour état réel, liens et limites. |
| GUIDE_JOUR_PAR_JOUR.md | Version texte de ce guide | La lire directement sur GitHub. |
| config/ | Hypothèses et formats | Versionner les changements dans un nouveau fichier si besoin. |
| ecity/models.py | Modèles Python fournis | Lire, expliquer puis étendre de façon contrôlée. |
| tools/run_ecity.py | Exécution et export | Choisir le groupe, la configuration et le dossier de sortie. |
| tests/ | Vérification numérique du code | Exécuter avant les commits. |
| docs/ | Dossier d’ingénierie | Compléter les gabarits jour par jour. |
| journal/dayNN.md | Trace d’apprentissage | Écrire action, résultat, limite et suite. |
| reports/dayNN/ | Preuves que tu as générées | Versionner les rapports sélectionnés. |
| reports/_scratch/ | Essais temporaires ignorés par Git | Utiliser pour explorer ou vérifier un clone. |

### Ce que vérifient les 12 tests

Unités et chiffres de référence, pente en ratio, régime, autonomie, freinage et intégration, domaine invalide, combinaison des délais, charge réseau, couple signé et frontière du timeout.

Un test Python réussi vérifie la cohérence attendue du modèle. Il ne valide pas un véhicule réel. Les sorties de performance peuvent contenir un FAIL de comparaison attendu alors que les tests du logiciel sont corrects.

## Installer le projet et publier le premier commit

Cours p. 2-9 - Initialisation sur main ; un seul premier push.

**But.** Obtenir un dossier local exécutable et un dépôt GitHub E-City distinct de tes autres projets.

**1.** Extrais le kit E-City dans Documents. Ouvre CMD dans ce dossier, puis vérifie Git et Python avec les commandes ci-dessous.
**2.** Lis README.md. Complète docs/01_cadrage.md : usage urbain, conducteur, borne, route, environnement, frontière et trois exclusions de périmètre.
**3.** Ouvre config/reference.json. Vérifie les unités et conserve les hypothèses du cours ; ne transforme pas une valeur supposée en mesure.
**4.** Crée un dépôt E-City sur GitHub, vide, sans README ajouté sur le site. Copie son URL HTTPS. Effectue le premier push selon la page Installation.

**Fichiers de travail :** docs/01_cadrage.md, config/reference.json, journal/day01.md.

```bat
git --version
py --version
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Les 12 tests du kit passent. Le dépôt distant affiche le README et les dossiers ; aucun rapport exécuté par toi n’est encore revendiqué.
**Avant de terminer :** Tu expliques la frontière, les flux et le rôle de Git par rapport à GitHub.

**Publication :** complète d’abord journal/day01.md, puis utilise une seule fois la procédure « premier envoi ». Le commit initial s’appelle chore: initialise E-City learning project.

**À expliquer en 60 secondes :** Quel résultat veux-tu démontrer sur ordinateur ?

## Dimensionner la traction sur le plat et en pente

Cours p. 9-12 et 18 - main à jour, puis créer ou reprendre la branche jour-02.

**But.** Identifier le scénario qui dimensionne la puissance continue et vérifier le rapport de réduction.

**1.** Ouvre une branche jour-02 avec la routine Git. Relis les équations de force, puissance et régime.
**2.** Exécute roadload. Ouvre reports/day02/roadload.csv ; distingue puissance roues, mécanique machine et électrique batterie.
**3.** Dans docs/02_dimensionnement.md, recalcule à la main le roulement et l’aérodynamique à 50 km/h. Compare 90 km/h plat et 70 km/h en pente de 8 %.
**4.** Justifie provisoirement 30 kW continus, 50 kW crête et i = 9. Dessine ICE/boîte et batterie/inverter/machine pour expliquer les conversions.

**Fichiers de travail :** docs/02_dimensionnement.md, reports/day02, journal/day02.md.

```bat
py tools/run_ecity.py roadload --out reports/day02
```

### Résultat et contrôle

À 50 km/h : 3,012 kW roues. En pente : 25,130 kW mécaniques machine. À 90 km/h : environ 7 674 tr/min.
**Avant de terminer :** Pente de 8 % = 0,08 et non 8 degrés ; les limites thermiques restent ouvertes.

```bat
git add docs/02_dimensionnement.md reports/day02 journal/day02.md
git diff --cached --stat
git commit -m "feat: document traction sizing and gear ratio"
git push -u origin jour-02
```

**À expliquer en 60 secondes :** Pourquoi la pente peut-elle dimensionner plus que la vitesse maximale ?

## Étudier énergie, autonomie et distance d’arrêt

Cours p. 13-17 - main à jour, puis créer ou reprendre la branche jour-03.

**But.** Comparer un résultat nominal à des sensibilités et distinguer consigne et capacité de freinage.

**1.** Exécute energy puis braking dans deux sous-dossiers. Ouvre leurs CSV et le fichier braking.svg avec ton navigateur.
**2.** Dans docs/03_energie_freinage.md, écris énergie brute, fenêtre utile et formule d’autonomie ; compare 130 et 150 Wh/km.
**3.** Recalcule l’arrêt nominal : vT + v²/(2a). Compare μ = 0,80 et μ = 0,35 ; explique le rôle de min(5, μg).
**4.** Note les limites : pas de cycle complet, de pneu détaillé ni de perception. Ajoute trois effets du changement de masse sur le châssis et la thermique.

**Fichiers de travail :** docs/03_energie_freinage.md, reports/day03, journal/day03.md.

```bat
py tools/run_ecity.py energy --out reports/day03/energy
py tools/run_ecity.py braking --out reports/day03/braking
```

### Résultat et contrôle

20,8 kWh utiles ; 160 km à 130 Wh/km ; 138,67 km à 150 Wh/km. Arrêt : 23,46 m puis 32,26 m.
**Avant de terminer :** Tu sais pourquoi le cas faible adhérence est une exploration hors du domaine nominal de REQ-04.

```bat
git add docs/03_energie_freinage.md reports/day03 journal/day03.md
git diff --cached --stat
git commit -m "feat: analyse energy range and braking sensitivity"
git push -u origin jour-03
```

**À expliquer en 60 secondes :** Qu’est-ce que le modèle démontre et qu’est-ce qui reste à essayer ?

## Écrire huit exigences et leurs preuves

Cours p. 19 et 75 - main à jour, puis créer ou reprendre la branche jour-04.

**But.** Transformer le besoin en obligations vérifiables reliées aux calculs.

**1.** Ouvre docs/04_exigences.csv dans un éditeur ou un tableur en UTF-8. Les huit lignes proposées sont des candidats à revoir, pas des exigences approuvées.
**2.** Complète les champs propriétaire, justification, conditions et preuve. Référence les rapports day02 et day03 lorsque leur domaine correspond.
**3.** Pour l’autonomie, garde la distinction entre calcul à consommation supposée et essai sur cycle à définir. Pour REQ-04, conserve explicitement μ = 0,80.
**4.** Marque les informations inconnues TBR, avec responsable et date cible. Ajoute dans ton journal un conflit entre autonomie et masse.

**Fichiers de travail :** docs/04_exigences.csv, journal/day04.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Huit identifiants stables ; aucune limite sans unité, condition ou méthode. Les preuves thermiques et temporelles restent ouvertes.
**Avant de terminer :** Tu peux remonter d’un résultat à son exigence et de l’exigence au besoin.

```bat
git add docs/04_exigences.csv journal/day04.md
git diff --cached --stat
git commit -m "docs: define requirements and verification criteria"
git push -u origin jour-04
```

**À expliquer en 60 secondes :** Quelle différence entre besoin, exigence et critère d’acceptation ?

## Allouer les fonctions et fixer les interfaces

Cours p. 20-27 et 76 - main à jour, puis créer ou reprendre la branche jour-05.

**But.** Relier fonctions, composants, échanges, états et budget temporel.

**1.** Complète docs/05_architecture.md avec trois vues distinctes : fonctionnelle, logique et physique. Le kit propose une base Mermaid visible sur GitHub.
**2.** Complète docs/05_interfaces.csv : émetteur, récepteur, grandeur, unité, codage, période, validité et réaction en défaut.
**3.** Exécute latency. Explique pourquoi caméra et radar en parallèle se combinent par un maximum, puis les autres étapes par addition.
**4.** Relie les exigences aux éléments responsables. Identifie qui possède la réserve de 50 ms et quelle preuve future vérifiera le délai intégré.

**Fichiers de travail :** docs/05_architecture.md, docs/05_interfaces.csv, reports/day05, journal/day05.md.

```bat
py tools/run_ecity.py latency --out reports/day05
```

### Résultat et contrôle

Budgets : 250 ms au nominal ; 290 ms avec caméra lente ; 305 ms en surcharge. Les 300 ms sont un critère d’exercice.
**Avant de terminer :** Aucune fonction importante sans allocation ; les flèches d’allocation et de flux sont distinguées.

```bat
git add docs/05_architecture.md docs/05_interfaces.csv reports/day05 journal/day05.md
git diff --cached --stat
git commit -m "docs: allocate functions and specify interfaces"
git push -u origin jour-05
```

**À expliquer en 60 secondes :** Deux blocs logiques impliquent-ils deux calculateurs ?

## Créer une baseline et étudier un changement

Cours p. 28-30 et 33 - main à jour, puis créer ou reprendre la branche jour-06.

**But.** Identifier une définition reproductible et préparer une analyse d’impact.

**1.** Complète docs/06_configuration.md : paramètres, modèle, exigences, ICD et rapports avec leurs versions ou hashes.
**2.** Après la fusion de la PR jour-06, crée le tag ecity-bl01 sur main avec la procédure des jalons. Il désigne la référence de concept à cette date.
**3.** Dans docs/06_changement.md, décris un remplacement d’inverter : gain de masse, nouveau connecteur et dissipation différente.
**4.** Énumère impacts mécanique, électrique, logiciel, thermal, safety, coût, planning, stock et preuves. N’applique pas encore un changement non décidé.

**Fichiers de travail :** docs/06_configuration.md, docs/06_changement.md, journal/day06.md.

```bat
git rev-parse HEAD
git log --oneline -5
```

### Résultat et contrôle

Une référence BL-01 identifiée et une ECR-01 avec options, impacts, décision provisoire, responsables et vérifications.
**Avant de terminer :** Un tag repère un commit ; il ne signifie pas validation physique ou conformité du véhicule.

```bat
git add docs/06_configuration.md docs/06_changement.md journal/day06.md
git diff --cached --stat
git commit -m "docs: record concept baseline and inverter change"
git push -u origin jour-06
```

**À expliquer en 60 secondes :** Pourquoi la version de calibration fait-elle partie de la preuve ?

## Relier nomenclature et industrialisation

Cours p. 29-32 et 43 - main à jour, puis créer ou reprendre la branche jour-07.

**But.** Préparer un raisonnement produit/process sans inventer une approbation de production.

**1.** Complète docs/07_ebom.csv : références candidates, quantité, rôle et maturité. Vérifie que les éléments existent dans l’architecture.
**2.** Dans docs/07_industrialisation.md, distingue EBOM, MBOM et SBOM. Donne un exemple de différence entre pièce conçue et opération d’assemblage.
**3.** Choisis le support inverter : caractéristique fonctionnelle, risque de fabrication, moyen de mesure et plan de réaction.
**4.** Écris les preuves à prévoir dans une démarche APQP/PPAP fictive. Signale les documents réellement absents et les règles client à obtenir.

**Fichiers de travail :** docs/07_ebom.csv, docs/07_industrialisation.md, journal/day07.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Une nomenclature cohérente et cinq preuves futures d’industrialisation. Le statut reste étude de concept.
**Avant de terminer :** Une pièce prototype dimensionnellement correcte ne prouve pas la répétabilité de la série.

```bat
git add docs/07_ebom.csv docs/07_industrialisation.md journal/day07.md
git diff --cached --stat
git commit -m "docs: link bill of materials and industrialisation"
git push -u origin jour-07
```

**À expliquer en 60 secondes :** Quelle différence entre APQP et PPAP ?

## Piloter le travail et les risques

Cours p. 34-39 - main à jour, puis créer ou reprendre la branche jour-08.

**But.** Construire un planning réalisable et une gouvernance des décisions.

**1.** Dans docs/08_programme.md, définis scope, livrables et critères d’achèvement. Prévois une charge compatible avec ton temps disponible.
**2.** Construis un WBS de dix tâches et leurs dépendances. Calcule un chemin critique ; sépare travail en parallèle et ressource réellement disponible.
**3.** Complète docs/08_risques.csv avec cinq risques, actions, responsables et échéances. Distingue un problème déjà présent d’un événement incertain.
**4.** Écris une escalade courte : fait, impact, options, recommandation et date de décision. Mets à jour ton avancement réel dans README.md.

**Fichiers de travail :** docs/08_programme.md, docs/08_risques.csv, README.md, journal/day08.md.

```bat
git status --short
git diff --stat
```

### Résultat et contrôle

Un plan avec responsables, dépendances, marge et cinq risques traitables, sans pourcentage d’avancement fondé sur les seules heures.
**Avant de terminer :** Tu sais dire ce qui doit être livré, qui décide et quelle preuve termine une action.

```bat
git add docs/08_programme.md docs/08_risques.csv README.md journal/day08.md
git diff --cached --stat
git commit -m "docs: plan milestones resources and risks"
git push -u origin jour-08
```

**À expliquer en 60 secondes :** Comment réagir à un retard fournisseur sans supprimer une preuve nécessaire ?

## Travailler comme responsable composant

Cours p. 40-44 - main à jour, puis créer ou reprendre la branche jour-09.

**But.** Spécifier et revoir l’intégration mécatronique de l’inverter.

**1.** Remplis docs/09_composant_inverter.md avec dix exigences de compatibilité. Classe chaque donnée : disponible, calculée, supposée ou à demander.
**2.** Précise les interfaces mécanique, électrique, réseau/logiciel, thermique et industrielle. Ne confonds pas puissance électrique et mécanique.
**3.** Prépare trois options de résolution d’un problème de surchauffe : support, refroidissement ou déclassement. Compare les impacts véhicule.
**4.** Rédige une mini design review : problème, données, options, décision provisoire et trois preuves de confirmation ou de rejet.

**Fichiers de travail :** docs/09_composant_inverter.md, journal/day09.md.

```bat
py tools/run_ecity.py roadload --out reports/_scratch/day09
```

### Résultat et contrôle

Une fiche de composant exploitable et une liste de questions fournisseur. Aucun tableau ne marque conforme une valeur inconnue.
**Avant de terminer :** Le refroidissement et la carte de fonctionnement restent des points ouverts identifiés.

```bat
git add docs/09_composant_inverter.md journal/day09.md
git diff --cached --stat
git commit -m "docs: review inverter interfaces and supplier evidence"
git push -u origin jour-09
```

**À expliquer en 60 secondes :** Le fournisseur annonce 30 kW : quelles questions poses-tu ?

## Décrire l’ECU et la chaîne de mesure

Cours p. 45-48 - main à jour, puis créer ou reprendre la branche jour-10.

**But.** Expliquer le chemin depuis la pédale jusqu’à l’actionneur.

**1.** Complète docs/10_ecu_capteurs.md avec alimentation/protection, conditionnement, ADC, MCU/mémoire, driver et transceiver.
**2.** Définis une chaîne de pédale : plage, loi de conversion, échantillonnage, unité, horodatage et état de validité.
**3.** Décris trois défauts : hors plage, valeur bloquée et incohérence entre pistes. Donne la relation de plausibilité au lieu d’exiger l’égalité sans raison.
**4.** Ajoute une interface de pompe thermique et un risque de CEM. Explique le compromis entre filtrage et retard.

**Fichiers de travail :** docs/10_ecu_capteurs.md, journal/day10.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Un schéma commenté complet et trois défauts reliés à un effet et un contrôle. Aucune électronique réelle n’est nécessaire.
**Avant de terminer :** Le contrôleur CAN et le transceiver physique sont deux fonctions différentes.

```bat
git add docs/10_ecu_capteurs.md journal/day10.md
git diff --cached --stat
git commit -m "docs: specify ECU sensor and actuator chains"
git push -u origin jour-10
```

**À expliquer en 60 secondes :** Pourquoi un microcontrôleur seul ne constitue-t-il pas un ECU automobile ?

## Simuler messages, codage et timeout

Cours p. 49-51 et 55 - main à jour, puis créer ou reprendre la branche jour-11.

**But.** Vérifier des contrats d’échange sans prétendre utiliser un bus CAN réel.

**1.** Lis config/messages.json. Les trois messages ont des identifiants 11 bits comparables, périodes 10/10/20 ms et une taille hypothétique de 130 bits chacun.
**2.** Exécute network. Contrôle la charge de 6,5 %, puis le codage 10 N·m → 64 00 little-endian avec une résolution de 0,1 N·m.
**3.** Dans docs/11_communication.md, analyse monitor.csv : à 30 ms la donnée est encore acceptée ; à 31 ms elle est périmée dans cette règle pédagogique.
**4.** Relie moniteur, diagnostic et état dégradé. Les 30 ms sont une valeur de démonstration à discuter dans REQ-06, pas une cible safety approuvée.

**Fichiers de travail :** docs/11_communication.md, reports/day11, journal/day11.md.

```bat
py tools/run_ecity.py network --out reports/day11
py -m unittest discover -s tests -v
```

### Résultat et contrôle

network.csv : 6,5 % ; monitor.csv : READY, READY, DEGRADED, DEGRADED pour les quatre cas fournis.
**Avant de terminer :** Tu distingues trame reçue, valeur décodée, donnée fraîche et action exécutée.

```bat
git add docs/11_communication.md reports/day11 journal/day11.md
git diff --cached --stat
git commit -m "feat: analyse abstract network and stale data cases"
git push -u origin jour-11
```

**À expliquer en 60 secondes :** Pourquoi un ACK CAN ne prouve-t-il pas que le couple a été appliqué ?

## Organiser états, logiciel et compatibilités

Cours p. 23, 52-54 - main à jour, puis créer ou reprendre la branche jour-12.

**But.** Choisir une architecture E/E candidate et un déploiement explicite.

**1.** Complète docs/12_logiciel_etats.md avec initialisation, prêt, traction, dégradé et arrêt contrôlé ; indique événements, gardes et sorties.
**2.** Définis les tâches : acquisition, limites, émission et diagnostic avec périodes et deadlines. Compare charge moyenne et preuve de respect des échéances.
**3.** Relie application, plateforme et matériel. Une organisation inspirée de couches logicielles ne constitue pas une implémentation AUTOSAR qualifiée.
**4.** Renseigne une matrice application/calibration/ICD et ferme ou justifie le TBR de fraîcheur de REQ-06. Conserve une date et une autorité simulée de décision.

**Fichiers de travail :** docs/12_logiciel_etats.md, docs/04_exigences.csv, journal/day12.md.

```bat
py tools/run_ecity.py latency --out reports/_scratch/day12
```

### Résultat et contrôle

Une logique d’états lisible, un budget de tâches et des compatibilités explicites. Les calculs temporels restent des budgets.
**Avant de terminer :** Deux fonctions dans le même calculateur partagent potentiellement ressources et défaillances.

```bat
git add docs/12_logiciel_etats.md docs/04_exigences.csv journal/day12.md
git diff --cached --stat
git commit -m "docs: define software states and compatibility"
git push -u origin jour-12
```

**À expliquer en 60 secondes :** Que se passe-t-il si la demande reste valide en contenu mais devient trop ancienne ?

## Analyser dangers, défaillances et limites

Cours p. 56-58 - main à jour, puis créer ou reprendre la branche jour-13.

**But.** Préparer une assurance fondée sur des scénarios et des mécanismes.

**1.** Dans docs/13_safety.md, décris trois situations : propulsion non demandée, freinage insuffisant et freinage intempestif.
**2.** Complète docs/13_fmea.csv : fonction, mode, effet, cause, détection, action et preuve. N’attribue pas d’ASIL à partir d’une intuition.
**3.** Analyse une panne commune : alimentation partagée, calculateur partagé ou horloge. Deux capteurs ne suffisent pas à prouver l’indépendance.
**4.** Écris la frontière SOTIF : le modèle reçoit une distance idéale et ne valide pas la détection réelle d’un piéton.

**Fichiers de travail :** docs/13_safety.md, docs/13_fmea.csv, journal/day13.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Trois situations dangereuses, trois lignes de FMEA et des preuves à obtenir. La conformité safety reste hors du résultat démontré.
**Avant de terminer :** La réaction générique DEGRADED du kit n’est pas une stratégie de sécurité véhicule validée.

```bat
git add docs/13_safety.md docs/13_fmea.csv journal/day13.md
git diff --cached --stat
git commit -m "docs: analyse hazards failure modes and model limits"
git push -u origin jour-13
```

**À expliquer en 60 secondes :** Quelle différence entre panne E/E et insuffisance de perception ?

## Relier cyber, qualité et plan d’essais

Cours p. 59-64 - main à jour, puis créer ou reprendre la branche jour-14.

**But.** Définir des contrôles et des essais reliés aux risques.

**1.** Complète docs/14_cyber_qualite.md avec actif, menace, frontière de confiance, traitement et preuve ; le CRC ne remplace pas l’authentification.
**2.** Pour le support inverter, relie risque de conception, risque de fabrication, mesure et plan de réaction. Explique ce qu’une MSA doit vérifier.
**3.** Complète docs/14_dvp.csv avec au moins six essais, dont deux défauts. Décris configuration, critère, niveau de preuve et statut réel.
**4.** Sépare analyses sur PC et futures preuves HIL/banc/véhicule ; le kit ne produit pas ces essais physiques.

**Fichiers de travail :** docs/14_cyber_qualite.md, docs/14_dvp.csv, journal/day14.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Une menace traitée, un plan de mesure et six lignes DVP avec critères. Les cases non exécutées restent ouvertes.
**Avant de terminer :** Chaque contrôle a une justification et un comportement observable à vérifier.

```bat
git add docs/14_cyber_qualite.md docs/14_dvp.csv journal/day14.md
git diff --cached --stat
git commit -m "docs: link cybersecurity quality and verification plan"
git push -u origin jour-14
```

**À expliquer en 60 secondes :** Que doit contenir un rapport d’essai pour être reproductible ?

## Comparer coûts et fournisseurs

Cours p. 65-69 - main à jour, puis créer ou reprendre la branche jour-15.

**But.** Justifier un choix avec volume, maturité et sensibilité.

**1.** Complète docs/15_cout.csv et docs/15_decision_cout.md : périmètre, monnaie, quantité, estimation et exclusions.
**2.** Reproduis le coût traction partiel de 6 000 € du cours ; distingue somme pièces et assemblage. Tous les prix sont fictifs.
**3.** Compare A : 100 k€ + 550 €/pièce et B : 200 k€ + 500 €/pièce ; calcule le seuil de 2 000 pièces.
**4.** Ajoute une troisième option C de ton choix, puis compare à 1 000 et 10 000 pièces. Signale les différences de contenu, maturité, délai et capacité.

**Fichiers de travail :** docs/15_cout.csv, docs/15_decision_cout.md, journal/day15.md.

```bat
git diff --stat
```

### Résultat et contrôle

Un calcul économique vérifiable et une décision qui peut changer avec le volume. Aucun prix de marché ni devis réel n’est revendiqué.
**Avant de terminer :** Une économie pièce ne compense pas une exigence obligatoire non satisfaite.

```bat
git add docs/15_cout.csv docs/15_decision_cout.md journal/day15.md
git diff --cached --stat
git commit -m "docs: compare concept cost and supplier options"
git push -u origin jour-15
```

**À expliquer en 60 secondes :** Pourquoi le fournisseur au prix pièce le plus faible peut-il ne pas être le meilleur choix ?

## Rendre les données interprétables

Cours p. 70-73 - main à jour, puis créer ou reprendre la branche jour-16.

**But.** Construire un dictionnaire, un rapport et une conclusion limitée.

**1.** Exécute all dans reports/day16. Lis summary.json : modèle, timestamp UTC, paramètres, hashes et état Git avant exécution.
**2.** Complète docs/16_donnees.md : sens, unité, source et validité des principales colonnes. Toutes les sorties du kit sont synthétiques.
**3.** Relie les résultats aux exigences et distingue marge, échec de comparaison et preuve manquante. Conserve le cas 305 ms et le cas faible adhérence.
**4.** Dans README.md, ajoute les liens vers le rapport et le graphique. Explique en quatre phrases le passage donnée → information → connaissance → décision.

**Fichiers de travail :** docs/16_donnees.md, reports/day16, README.md, journal/day16.md.

```bat
py tools/run_ecity.py all --out reports/day16
```

### Résultat et contrôle

CSV, JSON, README de rapport et courbe SVG. Les hashes permettent d’identifier les entrées et le code réellement utilisés.
**Avant de terminer :** Le commit enregistré peut précéder le rapport ; working_tree_clean indique l’état avant le calcul, sans prétendre que tous les fichiers étaient déjà commités.

```bat
git add docs/16_donnees.md reports/day16 README.md journal/day16.md
git diff --cached --stat
git commit -m "feat: organise synthetic results and data dictionary"
git push -u origin jour-16
```

**À expliquer en 60 secondes :** Pourquoi une moyenne favorable peut-elle masquer un résultat critique ?

## Assembler la synthèse intégrée

Cours p. 74-80 - main à jour, puis créer ou reprendre la branche jour-17.

**But.** Vérifier la cohérence entre physique, système, industrie et économie.

**1.** Complète docs/17_synthese.md avec huit sections : besoin, hypothèses, calculs, exigences, architecture, configuration, risques/preuves et décision.
**2.** Retrouve les chiffres à la source : 160 km de référence, 25,13 kW mécaniques de pente, 23,46 m d’arrêt nominal et 250 ms de budget.
**3.** Vérifie que REQ, ICD, BOM, FMEA et DVP désignent les mêmes éléments. Écris les preuves physiques encore ouvertes.
**4.** Formule une décision de poursuite conditionnelle et trois résultats capables de la réfuter. Termine par les trois prochaines actions prioritaires.

**Fichiers de travail :** docs/17_synthese.md, docs/04_exigences.csv, docs/14_dvp.csv, journal/day17.md.

```bat
py -m unittest discover -s tests -v
```

### Résultat et contrôle

Un dossier court où chaque conclusion renvoie à une preuve ou à une hypothèse identifiée.
**Avant de terminer :** La synthèse ne transforme ni un budget en mesure ni une analyse de concept en validation véhicule.

```bat
git add docs/17_synthese.md docs/04_exigences.csv docs/14_dvp.csv journal/day17.md
git diff --cached --stat
git commit -m "docs: consolidate integrated E-City concept dossier"
git push -u origin jour-17
```

**À expliquer en 60 secondes :** Quelle décision recommandes-tu aujourd’hui, avec quelles réserves ?

## Exécuter une campagne et propager un changement

Cours p. 77-79 et 83-85 - main à jour, puis créer ou reprendre la branche jour-18.

**But.** Comparer la référence à une configuration plus lourde et analyser les limites.

**1.** Exécute all pour la référence. Copie config/reference.json en config/mass_1300.json et remplace seulement mass_kg = 1200 par 1300, avec un nouvel identifiant.
**2.** Exécute all avec --config sur le second fichier. Compare les CSV de traction et note pourquoi l’arrêt à décélération constante reste identique dans ce modèle.
**3.** Complète docs/18_campagne.md : scénario, configuration, attendu, obtenu, verdict et limite. Reprends le scénario de surcharge de calcul à 305 ms.
**4.** Mets à jour ECR-02 dans docs/06_changement.md et la matrice DVP. Le code qui s’exécute sans erreur peut produire un résultat de performance défavorable attendu.

**Fichiers de travail :** config/mass_1300.json, reports/day18-reference, reports/day18-mass1300, docs/18_campagne.md, docs/06_changement.md, docs/14_dvp.csv, journal/day18.md.

```bat
copy config\reference.json config\mass_1300.json
notepad config\mass_1300.json
py tools/run_ecity.py all --out reports/day18-reference
py tools/run_ecity.py all --config config/mass_1300.json --out reports/day18-mass1300
```

### Résultat et contrôle

Les résistances liées à la masse et la puissance de pente augmentent. Le freinage constant-a ne contient pas la masse ; son invariance est une limite du modèle.
**Avant de terminer :** Les rapports portent des hashes de configuration différents et conservent les scénarios défavorables.

```bat
git add config/mass_1300.json reports/day18-reference reports/day18-mass1300 ^
  docs/18_campagne.md docs/06_changement.md docs/14_dvp.csv journal/day18.md
git diff --cached --stat
git commit -m "test: compare reference and increased mass campaign"
git push -u origin jour-18
```

**À expliquer en 60 secondes :** Quelles preuves faut-il rouvrir quand la masse change ?

## Vérifier depuis un clone neuf et s’entraîner

Cours p. 80 et 86-90 - main à jour, puis créer ou reprendre la branche jour-19.

**But.** Prouver la reproductibilité du dépôt et préparer l’oral.

**1.** Complète docs/19_entretien.md : présentation de cinq minutes, quinze questions, trois choix et une limite que tu sais défendre.
**2.** Fusionne la PR du jour, puis suis la procédure Clone neuf. Les commandes doivent fonctionner dans un autre dossier sans fichier local caché manquant.
**3.** Dans le clone, exécute les tests puis all vers reports/_scratch/clone-check. Compare les valeurs numériques ; timestamps et états Git peuvent différer.
**4.** Note la vérification dans journal/day19.md par un nouveau commit si nécessaire. Termine le README : état réel, démarrage, résultats, limites et liens.

**Fichiers de travail :** docs/19_entretien.md, README.md, journal/day19.md.

```bat
py -m unittest discover -s tests -v
py tools/run_ecity.py all --out reports/_scratch/recheck
```

### Résultat et contrôle

Douze tests réussis et résultats reproduits dans un clone distinct. Les fichiers _scratch restent ignorés.
**Avant de terminer :** Un recruteur peut suivre le README et retrouver la limite principale en moins de deux minutes.

```bat
git add docs/19_entretien.md README.md journal/day19.md
git diff --cached --stat
git commit -m "docs: verify reproducibility and prepare interview"
git push -u origin jour-19
```

**À expliquer en 60 secondes :** Qu’as-tu effectivement réalisé toi-même et avec quels outils ?

## Finaliser la version de portfolio

Cours p. 91 - main à jour, puis créer ou reprendre la branche jour-20.

**But.** Présenter un état honnête, stable et facile à parcourir.

**1.** Dans journal/day20.md et README.md, résume réalisé, ouvert et prochaine étape. Corrige les trois points faibles de l’entretien blanc sans ajouter de fonction.
**2.** Exécute les tests, relis le diff et fusionne la PR jour-20. Actualise main puis crée le tag ecity-v0.1.0 selon la page Jalons.
**3.** Sur GitHub, crée éventuellement une Release à partir du tag existant ; les notes décrivent une étude virtuelle, les résultats et les limites.
**4.** Épingle le dépôt sur ton profil si tu souhaites le montrer. Vérifie ses liens et partage seulement la visibilité que tu as choisie.

**Fichiers de travail :** README.md, journal/day20.md.

```bat
py -m unittest discover -s tests -v
git status --short
```

### Résultat et contrôle

Une version de portfolio reproductible, des hypothèses explicites et une présentation de cinq minutes prête pour le 12 novembre.
**Avant de terminer :** Le tag final pointe vers la version fusionnée ; les limites safety, thermique et validation physique restent visibles.

```bat
git add README.md journal/day20.md
git diff --cached --stat
git commit -m "docs: finalise virtual concept portfolio"
git push -u origin jour-20
```

**À expliquer en 60 secondes :** Quelle serait ta prochaine étape si tu disposais d’un banc et de données fournisseur ?

## Comprendre les fichiers générés

Exemple après py tools/run_ecity.py all --out reports/day18-reference.

| Fichier | Contenu | Comment l’utiliser |
| --- | --- | --- |
| roadload.csv | Forces, puissances, régime et marge | Comparer roues, machine et batterie ; lire le scénario. |
| energy.csv | Référence et sensibilités | Ne pas confondre avec un cycle mesuré. |
| braking.csv | Distances et comparaison | Lire requirement_status et le domaine nominal. |
| trace_nominal.csv | Temps, vitesse, distance | Reproduire la courbe ou vérifier un instant. |
| braking.svg | Deux courbes de vitesse | Afficher sur GitHub depuis le README du rapport. |
| latency.csv | Budgets nominal, lent et surcharge | Un budget est distinct d’une mesure HIL. |
| network.csv / monitor.csv | Charge, codage et fraîcheur | Messages abstraits, sans matériel CAN. |
| summary.json | Résultats et métadonnées | Paramètres, hashes, version et état Git. |
| README.md | Index et graphe du rapport | Lien direct à mettre dans le README principal. |

**Point de traçabilité :** les rapports sont produits avant le commit qui les ajoute. git_commit_before_run peut donc désigner le commit précédent. Le hash source identifie les fichiers Python, le hash config identifie le JSON et working_tree_clean_before_run signale les changements présents. Cette transparence évite une fausse attribution.

### Reproduire

Compare les résultats numériques et les paramètres. Les dates UTC, le chemin de sortie et l’état de travail peuvent changer entre deux exécutions ; cela n’implique pas que la physique du modèle a changé.

## Les valeurs que tu dois retrouver

Ces résultats viennent des hypothèses du cours et du code de référence.

| Analyse | Valeur attendue | Interprétation |
| --- | --- | --- |
| 50 km/h, plat | 216,88 N ; 3,012 kW roues | 4,147 kW électriques avec rendement et auxiliaires. |
| 90 km/h, plat | 9,657 kW roues ; 7 674 tr/min | Vérifier carte fournisseur et régime limite. |
| 70 km/h, pente 8 % | 25,130 kW mécaniques machine | Candidate continue 30 kW, thermique ouverte. |
| Énergie utile | 20,8 kWh | 26 × 0,8. |
| Autonomie de référence | 160 km | 20 800 / 130 Wh/km. |
| Consommation 150 Wh/km | 138,67 km | Objectif 150 km non atteint dans cette hypothèse. |
| Arrêt μ = 0,80 | 23,4568 m ; 3,0778 s | Cas nominal d’exercice. |
| Arrêt μ = 0,35 | 32,2577 m ; 4,3451 s | Exploration hors du domaine nominal REQ-04. |
| Budget réaction | 250 / 290 / 305 ms | Marge 50 / 10 / −5 ms. |
| Charge abstraite CAN | 6,5 % | 130 bits supposés ; périodes 10/10/20 ms. |

### Écart de résultat

Commence par comparer unité, virgule/point, masse, vitesse, pente, rendement et fichier JSON choisi. Vérifie ensuite la version du code. Un écart ne se corrige pas en ajustant le résultat à la main.

Une hausse de masse peut augmenter la puissance de pente sans modifier la distance d’arrêt du modèle constant-a. Explique cette structure du modèle avant d’en tirer une conclusion sur un véhicule réel.

## Repérer les versions importantes

Un tag pointe un commit ; il se crée après fusion et synchronisation de main.

Après la PR de J6 : référence du concept

```bat
git switch main
git pull --ff-only
git status
git tag -a ecity-bl01 -m "Concept baseline after day 06"
git push origin ecity-bl01
```

Après la PR de J20 : version de portfolio

```bat
git switch main
git pull --ff-only
py -m unittest discover -s tests -v
git status
git tag -a ecity-v0.1.0 -m "Virtual concept portfolio"
git push origin ecity-v0.1.0
```

Crée un tag uniquement si les modifications voulues sont commités, fusionnées et les contrôles satisfaisants. Si un tag existe déjà, inspecte-le ; ne le déplace pas silencieusement. Le numéro désigne ici le dossier virtuel, pas une maturité industrielle.

Release GitHub facultative

Sur GitHub, ouvre Releases, prépare une nouvelle release et sélectionne le tag existant ecity-v0.1.0. Décris : périmètre, commandes, résultats synthétiques, un cas défavorable et preuves ouvertes. Publie si tu veux partager cette version avec l’audience de ton dépôt.

### Message exact à préserver

« Étude de concept et validation de modèles simplifiés sur PC. Aucun essai véhicule, certification safety ni performance fournisseur n’est revendiqué. »

## Vérifier que le dépôt suffit à reproduire le travail

À faire après avoir poussé et fusionné les fichiers nécessaires.

**1.** Depuis le dossier Documents, crée un clone dans un répertoire distinct. Remplace l’URL par celle de ton dépôt. Le dossier E-City-relecture doit être nouveau.

```bat
cd /d "%USERPROFILE%\Documents"
git clone https://github.com/VOTRE_LOGIN/E-City.git E-City-relecture
cd E-City-relecture
py -m unittest discover -s tests -v
py tools/run_ecity.py all --out reports/_scratch/clone-check
git status --short
```

**2.** Attendu : 12 tests OK ; les mêmes valeurs numériques que la référence ; aucun fichier du rapport temporaire dans git status, car _scratch est ignoré. Ouvre le README et les liens avec ce seul dossier.

**3.** Reviens dans ton dépôt de travail. Note le résultat de cette vérification dans le journal et crée un commit de correction si nécessaire. Si le clone échoue faute d’un fichier non poussé, ajoute la bonne entrée dans le dépôt, puis refais la vérification ciblée.

```bat
cd /d "%USERPROFILE%\Documents\E-City"
git switch main
git pull --ff-only
```

### Ce que cette preuve apporte

Quelqu’un peut repartir du dépôt distant et retrouver les modèles, données d’entrée et résultats. Cela démontre la reproductibilité de l’étude dans son périmètre, pas celle d’un véhicule physique.

### Répertoire de travail

Évite de continuer tes journées par erreur dans E-City-relecture. Le dépôt principal reste E-City ; garde le clone comme contrôle séparé.

## Résoudre les blocages fréquents

Commence par lire le premier message d’erreur complet.

| Message ou symptôme | Vérification / correction |
| --- | --- |
| git non reconnu | Installer Git for Windows, puis rouvrir CMD ; tester git --version. |
| py non reconnu | Tester python --version ; si présent, utiliser python partout. Sinon installer Python. |
| Impossible d’ouvrir run_ecity.py | Faire dir et vérifier le dossier racine ; la commande part de E-City, pas de tools. |
| No module named ecity aux tests | Lancer py -m unittest discover -s tests -v depuis la racine du dépôt. |
| Erreur JSON | Conserver guillemets doubles, points décimaux et virgules entre champs ; supprimer commentaires et virgule finale. |
| Graphique absent | Exécuter braking ou all ; ces commandes produisent braking.svg. |
| CSV mal présenté dans Excel | Importer le fichier en UTF-8 avec séparateur virgule ; ne pas déduire les colonnes du séparateur régional. |
| Extension cachée | Vérifier qu’un fichier .py ou .json n’est pas en réalité .txt. |

Le kit ne demande pas de compiler du C++, de configurer MATLAB ni de brancher du matériel. Si un message demande une bibliothèque externe, vérifie que tu exécutes les fichiers fournis dans ce kit.

### Méthode de diagnostic

Note la commande, le dossier courant et le message exact. Reproduis sur une seule commande, corrige une cause puis relance. Ne change pas plusieurs paramètres simultanément pour « voir si ça passe ».

## Comprendre un push refusé

Inspecte avant de modifier l’historique.

| Situation | Action adaptée |
| --- | --- |
| remote origin already exists | Exécuter git remote -v. Si l’URL est réellement mauvaise : git remote set-url origin URL_CORRECTE. |
| src refspec main does not match | Vérifier git branch --show-current et git log -1 ; il faut un commit et la bonne branche. |
| Authentication failed / 403 | Vérifier compte, URL et droits ; reconnecter le compte via Git Credential Manager. Ne pas mettre de jeton dans le code ou l’URL. |
| nothing to commit | Tu n’as rien changé ou rien sélectionné ; comparer git status et git diff. Pas besoin de créer un faux commit. |
| jour-NN exists | Si tu reprends cette journée : git switch jour-NN, puis continuer. |
| main avance sur GitHub | Sur une branche propre : git fetch origin puis git merge origin/main ; traiter les conflits, tester et pousser. |
| pull --ff-only refuse | Les historiques ont divergé ; inspecter git log --oneline --graph --all -15 avant de choisir une fusion. |
| Modifications locales bloquent switch | Finir et commiter le travail dans sa branche, ou le sauvegarder explicitement. |

### Conflit de fichier

Lis les deux versions et conserve le contenu voulu, retire les marqueurs de conflit, puis git add sur les fichiers résolus et git commit. Refaire les vérifications avant git push.

Le guide ne nécessite aucun push forcé ni reset destructif. Si un fichier a seulement été sélectionné par erreur : **git restore --staged CHEMIN** le retire de la sélection et conserve son contenu local.

## Savoir quand poursuivre ou corriger

Le rythme sert la compréhension et la qualité du dossier.

**Si tu manques une journée :** conserve la séquence, regroupe les lectures proches et réduis les extensions. Garde en priorité cadrage, calculs, exigences, interfaces, un cas de défaut, traçabilité et présentation. Inscris la date réelle dans le journal.

**Si un test Python échoue :** vérifie unité, domaine et implémentation ; le test protège le modèle. Ne le supprime pas pour retrouver OK. Les valeurs flottantes se comparent avec une tolérance adaptée, pas toujours par égalité exacte.

**Si une performance est défavorable :** le code peut être correct. Le scénario de surcharge à 305 ms et le freinage faible adhérence sont justement là pour montrer des limites. Décris la conclusion dans le bon domaine et ouvre une action.

| Fermeture d’une journée | Question de contrôle |
| --- | --- |
| Contenu | Ai-je produit une analyse personnelle, pas seulement conservé le gabarit ? |
| Calcul | Les entrées, unités et hypothèses sont-elles connues ? |
| Preuve | Le rapport correspond-il à la configuration ? |
| Git | Le diff relu correspond-il à cette journée ? |
| Communication | Puis-je expliquer un choix et une limite en une minute ? |

### Journal minimal

Aujourd’hui : action et fichiers.
Résultat : chiffre avec unité et configuration.
Décision : choix et justification.
Limite : ce qui reste ouvert.
Demain : prochaine étape concrète.

Une PR peut rester en cours si le travail n’est pas prêt. La journée suivante commence avec un état connu ; elle ne doit pas masquer le défaut ou prétendre qu’un livrable est terminé.

## Préparer un dépôt lisible pour l’entretien

Références consultées le 22 octobre 2026.

**À la fin :** le README présente le besoin, le périmètre, les commandes, les résultats, les liens vers les preuves et les limites. Le dossier contient une configuration, un historique de décisions et un scénario qui remet le concept en question. Les pages GitHub reflètent les activités réellement réalisées.

**Source pédagogique :** Formation Automobile - 20 jours / Projet E-City, cours de 106 pages préparé dans cette conversation. Hypothèses, calendrier et exemples numériques conservés ; ce guide ajoute l’exécution, les livrables et le workflow de dépôt.

**GitHub Docs : ajouter du code local.**
[docs.github.com - Adding locally hosted code to GitHub](https://docs.github.com/en/migrations/importing-source-code/using-the-command-line-to-import-source-code/adding-locally-hosted-code-to-github)

**GitHub Docs : authentification et Credential Manager.**
[docs.github.com - Caching your GitHub credentials in Git](https://docs.github.com/en/get-started/git-basics/caching-your-github-credentials-in-git)

**GitHub Docs : créer une pull request.**
[docs.github.com - Creating a pull request](https://docs.github.com/en/pull-requests/how-tos/create-pull-requests/creating-a-pull-request)

**Git : commande pull et option fast-forward.**
[git-scm.com/docs/git-pull](https://git-scm.com/docs/git-pull)

**Python pour Windows.**
[python.org/downloads/windows/](https://www.python.org/downloads/windows/)

### À dire en entretien après réalisation

« J’ai construit un dossier de concept véhicule, exécuté des modèles simples et suivi les paramètres, résultats et décisions dans Git. J’ai identifié un scénario dimensionnant et des limites. Les tests physiques et les données fournisseur restent les étapes suivantes. »

Le kit livré contient le code de départ, les 20 journaux, les gabarits de documents et une version Markdown de ce guide. Aucun dépôt distant n’a été créé ni modifié par la génération de ces fichiers.
