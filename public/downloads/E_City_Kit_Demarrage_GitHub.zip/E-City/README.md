# E-City

Conception et validation virtuelle d'un véhicule électrique urbain.

## État du dépôt

Kit pédagogique de démarrage : modèles de référence fournis, documents et journal à compléter.
Les calculs sont synthétiques. Aucun essai réel, homologation, conformité safety ou performance fournisseur n'est revendiqué.

## Démarrer sous Windows (CMD)

```bat
py --version
py -m unittest discover -s tests -v
py tools/run_ecity.py all --out reports/_scratch/first-run
```

Python 3.10 ou plus récent ; bibliothèque standard uniquement, sans installation pip.
Si `py` est absent mais `python` fonctionne, remplacer `py` par `python` dans toutes les commandes.

## Méthode

- [Guide jour par jour](GUIDE_JOUR_PAR_JOUR.md)
- [Cadrage](docs/01_cadrage.md)
- [Synthèse intégrée](docs/17_synthese.md)
- [Journal](journal/)

Chaque jour : lire le cours, modifier les fichiers, exécuter les vérifications, interpréter les résultats,
compléter le journal puis publier une branche et fusionner une pull request.

## Modèles disponibles

- Charge routière et rapport de réduction.
- Énergie utile et autonomie de référence.
- Freinage à décélération constante, limité par mu*g.
- Budget de réaction séquentiel/parallèle.
- Messages abstraits : charge bus, codage de couple, validité et timeout.

## Résultats du travail personnel

À renseigner progressivement : liens vers les rapports exécutés, choix réellement analysés et limites.
La présence d'un document modèle ne signifie pas qu'il a été complété.

## Limites

Rendements constants, consommation de référence supposée, pas de carte machine ni de modèle thermique qualifié.
Pas de perception d'obstacles ni de réseau CAN physique. Le moniteur READY/DEGRADED est un exemple logique,
pas une stratégie de sécurité véhicule approuvée. Les montants économiques sont fictifs.

## Reproductibilité

Les rapports enregistrent paramètres, empreintes SHA256, version de modèle, date UTC et état Git avant calcul.
Un commit enregistré peut précéder le rapport. Les valeurs se comparent à hypothèses identiques ; les dates diffèrent.
Le kit et les modèles de référence doivent être distingués des analyses et décisions effectuées personnellement.
