# Cadrage

Statut : A_COMPLETER. Document de travail personnel.

## Besoin utilisateur et usage

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Frontière et acteurs externes

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Flux énergie, matière et information

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Livrables et exclusions

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Hypothèses et questions ouvertes

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
