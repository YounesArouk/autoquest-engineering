# Energie freinage

Statut : A_COMPLETER. Document de travail personnel.

## Énergie brute et utile

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Autonomie à 130 / 150 Wh/km

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Freinage nominal et faible adhérence

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Récupération et châssis

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Portée des preuves

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
