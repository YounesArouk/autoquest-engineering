# Architecture

Statut : A_COMPLETER. Document de travail personnel.

## Vue fonctionnelle

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Vue logique

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Vue physique et déploiement

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## États et transitions

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Allocation des exigences et budget temporel

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Exemple de vue à revoir

```mermaid
flowchart TB
    BMS["BMS : limites énergie"] --> VCU["VCU : demande et supervision"]
    PED["Pédale : mesure valide"] --> VCU
    VCU --> INV["Inverter : commande de machine"]
    INV --> MOT["Machine et transmission"]
    VCU --> BRK["Commande de freinage"]
```

Cet exemple représente des échanges ; il ne remplace pas les trois vues demandées.
