# Changement

Statut : A_COMPLETER. Document de travail personnel.

## ECR-01 : remplacement inverter

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Options et impacts

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Autorité et décision provisoire

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Preuves à refaire et effectivité

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## ECR-02 : masse 1300 kg (J18)

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
