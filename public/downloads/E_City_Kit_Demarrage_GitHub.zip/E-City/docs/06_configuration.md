# Configuration

Statut : A_COMPLETER. Document de travail personnel.

## Identité de BL-01

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Fichiers et versions

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Paramètres, sources et hashes

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Compatibilités

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Preuves et réserves

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
