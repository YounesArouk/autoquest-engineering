# Programme

Statut : A_COMPLETER. Document de travail personnel.

## Scope et critères de livraison

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## WBS avec charge et dépendances

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Chemin critique et marge

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Rôles et décision

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Exemple d’escalade et suivi

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
