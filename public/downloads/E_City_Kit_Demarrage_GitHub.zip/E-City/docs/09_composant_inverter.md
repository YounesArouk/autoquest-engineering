# Composant inverter

Statut : A_COMPLETER. Document de travail personnel.

## Exigences de compatibilité (dix lignes)

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Données disponibles et questions fournisseur

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Interfaces mécanique / électrique / logiciel / thermique

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Trois options contre la surchauffe

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Mini design review et trois preuves

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
