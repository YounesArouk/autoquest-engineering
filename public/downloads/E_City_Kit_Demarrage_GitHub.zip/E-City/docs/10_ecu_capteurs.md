# Ecu capteurs

Statut : A_COMPLETER. Document de travail personnel.

## Schéma de l’ECU

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Chaîne de mesure de pédale

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Conversion et plausibilité

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Défauts, timing et validité

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Actionneur thermique et CEM

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
