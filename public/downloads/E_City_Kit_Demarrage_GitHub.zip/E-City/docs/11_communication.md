# Communication

Statut : A_COMPLETER. Document de travail personnel.

## Définition des trois messages

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Charge réseau et limites de l’estimation

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Codage, endian et couple signé

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Timeout 30 ms : statut pédagogique

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Diagnostic et effets observables

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
