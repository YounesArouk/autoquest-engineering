# Logiciel etats

Statut : A_COMPLETER. Document de travail personnel.

## Machine à états

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Tâches, périodes et échéances

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Déploiement et ressources partagées

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Matrice application / calibration / ICD

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Décision sur REQ-06 et limites

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
