# Decision cout

Statut : A_COMPLETER. Document de travail personnel.

## Périmètre et hypothèses fictives

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Coût traction partiel

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Trois offres et volume

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Seuils et sensibilités

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Choix provisoire et risques

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
