# Entretien

Statut : A_COMPLETER. Document de travail personnel.

## Présentation de cinq minutes

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Trois choix justifiés

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Un écart et son analyse

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Quinze questions et mes réponses

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.

## Clone neuf : commandes et résultats

A_COMPLETER : raisonnement, donnée, source ou preuve ; ne pas seulement recopier une définition.
