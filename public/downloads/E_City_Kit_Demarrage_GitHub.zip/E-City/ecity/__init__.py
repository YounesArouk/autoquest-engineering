"""E-City: reference models for a virtual vehicle concept study."""
__version__ = "0.1.0"
