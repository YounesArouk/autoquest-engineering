"""Small, explicit models. All results are synthetic, not vehicle measurements."""
import math

G = 9.81

def positive(value, name, allow_zero=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(f"{name}: a number is required")
    if not math.isfinite(value) or value < 0 or (value == 0 and not allow_zero):
        raise ValueError(f"{name}: outside the model domain")
    return value

def validate_config(p):
    keys = ["mass_kg", "wheel_radius_m", "air_density_kg_m3", "drag_coefficient",
            "frontal_area_m2", "rolling_coefficient", "battery_kwh",
            "usable_fraction", "traction_efficiency", "gear_efficiency",
            "gear_ratio", "reference_wh_km", "range_target_km",
            "continuous_motor_kw", "peak_motor_kw", "max_motor_rpm",
            "battery_voltage_v", "bus_bitrate", "comparison_stop_m"]
    for key in keys:
        if key not in p:
            raise ValueError(f"Missing configuration key: {key}")
        positive(p[key], key)
    positive(p["auxiliary_kw"], "auxiliary_kw", True)
    for key in ["usable_fraction", "traction_efficiency", "gear_efficiency"]:
        if p[key] > 1:
            raise ValueError(f"{key}: must be <= 1")
    return p

def road_load(p, speed_kmh, grade=0.0):
    positive(speed_kmh, "speed_kmh", True)
    if not math.isfinite(grade) or grade < 0:
        raise ValueError("This traction model accepts non-negative grades")
    v = speed_kmh / 3.6
    angle = math.atan(grade)
    rolling = p["rolling_coefficient"] * p["mass_kg"] * G * math.cos(angle)
    aero = 0.5 * p["air_density_kg_m3"] * p["drag_coefficient"] * p["frontal_area_m2"] * v*v
    slope = p["mass_kg"] * G * math.sin(angle)
    force = rolling + aero + slope
    wheel_kw = force * v / 1000
    return {"speed_kmh": speed_kmh, "grade": grade, "rolling_n": rolling,
            "aero_n": aero, "slope_n": slope, "total_force_n": force,
            "wheel_kw": wheel_kw, "motor_mechanical_kw": wheel_kw / p["gear_efficiency"],
            "battery_kw": wheel_kw / p["traction_efficiency"] + p["auxiliary_kw"]}

def motor_rpm(p, speed_kmh):
    positive(speed_kmh, "speed_kmh", True)
    return speed_kmh / 3.6 / (2*math.pi*p["wheel_radius_m"]) * 60 * p["gear_ratio"]

def range_estimate(p, wh_km=None, energy_factor=1.0):
    wh_km = p["reference_wh_km"] if wh_km is None else wh_km
    positive(wh_km, "wh_km")
    positive(energy_factor, "energy_factor")
    if energy_factor > 1:
        raise ValueError("energy_factor must be <= 1")
    energy = p["battery_kwh"] * p["usable_fraction"] * energy_factor
    return {"consumption_wh_km": wh_km, "energy_factor": energy_factor,
            "usable_kwh": energy, "range_km": energy * 1000 / wh_km}

def braking(speed_kmh=50, delay_s=0.30, mu=0.8, request_m_s2=5, dt_s=0.01):
    positive(speed_kmh, "speed_kmh", True)
    positive(delay_s, "delay_s", True)
    for value, name in [(mu, "mu"), (request_m_s2, "request_m_s2"), (dt_s, "dt_s")]:
        positive(value, name)
    a = min(request_m_s2, mu * G)
    v = v0 = speed_kmh / 3.6
    if v0 == 0:
        return {"distance_m": 0.0, "time_s": 0.0, "deceleration_m_s2": a,
                "analytic_distance_m": 0.0, "trace": [(0.0, 0.0, 0.0)]}
    # Bound the workload before a user-supplied configuration creates a huge run.
    if (delay_s + v0/a) / dt_s > 200000:
        raise ValueError("Too many steps: increase dt_s or revise inputs")
    x, t = 0.0, 0.0
    trace = [(t, v, x)]
    while v > 0:
        if t < delay_s:
            step = min(dt_s, delay_s-t)
            next_v = v
        else:
            step = min(dt_s, v/a)
            next_v = max(0.0, v-a*step)
        x += 0.5*(v+next_v)*step
        t += step
        v = next_v
        trace.append((t, v, x))
    analytic = v0*delay_s + v0*v0/(2*a)
    return {"distance_m": x, "time_s": t, "deceleration_m_s2": a,
            "analytic_distance_m": analytic, "trace": trace}

def reaction_ms(camera=60, radar=40, fusion=25, extra_wait=0):
    for value in [camera, radar, fusion, extra_wait]:
        positive(value, "latency component", True)
    return max(camera, radar) + 20 + fusion + 15 + 10 + 120 + extra_wait

def bus_load(messages, bitrate):
    positive(bitrate, "bitrate")
    total = 0.0
    for message in messages:
        positive(message["assumed_bits"], "assumed_bits")
        positive(message["period_ms"], "period_ms")
        total += message["assumed_bits"] / (message["period_ms"] / 1000)
    return total / bitrate

def encode_torque(torque_nm):
    if not math.isfinite(torque_nm):
        raise ValueError("Torque must be finite")
    raw = round(torque_nm / 0.1)
    if not -32768 <= raw <= 32767:
        raise ValueError("Torque outside signed 16-bit range")
    return raw.to_bytes(2, "little", signed=True)

def decode_torque(payload):
    if len(payload) != 2:
        raise ValueError("Exactly two bytes are required")
    return int.from_bytes(payload, "little", signed=True) * 0.1

def monitor_command(age_ms, valid=True, timeout_ms=30):
    positive(age_ms, "age_ms", True)
    positive(timeout_ms, "timeout_ms")
    fresh = valid and age_ms <= timeout_ms
    return {"mode": "READY" if fresh else "DEGRADED",
            "virtual_command_authorized": bool(fresh),
            "diagnostic": "NONE" if fresh else "INPUT_INVALID_OR_STALE"}
