# Jour 01 - Installer le projet et publier le premier commit

Date prevue : 23/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Quel résultat veux-tu démontrer sur ordinateur ?

A_COMPLETER
