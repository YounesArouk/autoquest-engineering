# Jour 02 - Dimensionner la traction sur le plat et en pente

Date prevue : 24/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Pourquoi la pente peut-elle dimensionner plus que la vitesse maximale ?

A_COMPLETER
