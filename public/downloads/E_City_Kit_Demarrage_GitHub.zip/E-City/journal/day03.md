# Jour 03 - Étudier énergie, autonomie et distance d’arrêt

Date prevue : 25/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Qu’est-ce que le modèle démontre et qu’est-ce qui reste à essayer ?

A_COMPLETER
