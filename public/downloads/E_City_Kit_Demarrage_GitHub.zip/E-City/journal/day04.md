# Jour 04 - Écrire huit exigences et leurs preuves

Date prevue : 26/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Quelle différence entre besoin, exigence et critère d’acceptation ?

A_COMPLETER
