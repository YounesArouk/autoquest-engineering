# Jour 05 - Allouer les fonctions et fixer les interfaces

Date prevue : 27/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Deux blocs logiques impliquent-ils deux calculateurs ?

A_COMPLETER
