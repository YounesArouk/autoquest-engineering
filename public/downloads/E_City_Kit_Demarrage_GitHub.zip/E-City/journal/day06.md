# Jour 06 - Créer une baseline et étudier un changement

Date prevue : 28/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Pourquoi la version de calibration fait-elle partie de la preuve ?

A_COMPLETER
