# Jour 08 - Piloter le travail et les risques

Date prevue : 30/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Comment réagir à un retard fournisseur sans supprimer une preuve nécessaire ?

A_COMPLETER
