# Jour 09 - Travailler comme responsable composant

Date prevue : 31/10/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Le fournisseur annonce 30 kW : quelles questions poses-tu ?

A_COMPLETER
