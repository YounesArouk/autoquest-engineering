# Jour 10 - Décrire l’ECU et la chaîne de mesure

Date prevue : 01/11/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Pourquoi un microcontrôleur seul ne constitue-t-il pas un ECU automobile ?

A_COMPLETER
