# Jour 11 - Simuler messages, codage et timeout

Date prevue : 02/11/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Pourquoi un ACK CAN ne prouve-t-il pas que le couple a été appliqué ?

A_COMPLETER
