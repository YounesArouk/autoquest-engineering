# Jour 15 - Comparer coûts et fournisseurs

Date prevue : 06/11/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Pourquoi le fournisseur au prix pièce le plus faible peut-il ne pas être le meilleur choix ?

A_COMPLETER
