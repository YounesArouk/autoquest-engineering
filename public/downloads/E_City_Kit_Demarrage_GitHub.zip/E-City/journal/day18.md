# Jour 18 - Exécuter une campagne et propager un changement

Date prevue : 09/11/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Quelles preuves faut-il rouvrir quand la masse change ?

A_COMPLETER
