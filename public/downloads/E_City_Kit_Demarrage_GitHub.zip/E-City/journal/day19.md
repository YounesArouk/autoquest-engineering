# Jour 19 - Vérifier depuis un clone neuf et s’entraîner

Date prevue : 10/11/2026. Date reelle : A_COMPLETER.

## Ce que j'ai fait et compris
A_COMPLETER

## Fichiers et commandes executes
A_COMPLETER

## Resultats, unites et configuration
A_COMPLETER

## Decision et limites
A_COMPLETER

## Difficultes et correction
A_COMPLETER

## Demain
A_COMPLETER

## Reponse orale
Qu’as-tu effectivement réalisé toi-même et avec quels outils ?

A_COMPLETER
