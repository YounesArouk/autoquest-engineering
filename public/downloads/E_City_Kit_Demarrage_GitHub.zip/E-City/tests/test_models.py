import unittest
import json
from pathlib import Path
from ecity.models import (road_load, motor_rpm, range_estimate, braking,
    reaction_ms, bus_load, encode_torque, decode_torque, monitor_command,
    validate_config)

ROOT = Path(__file__).resolve().parents[1]

class ModelsTest(unittest.TestCase):
    def setUp(self):
        self.p = validate_config(json.loads((ROOT / "config/reference.json").read_text()))

    def test_road_load_flat_50(self):
        r = road_load(self.p, 50)
        self.assertAlmostEqual(r["wheel_kw"], 3.0122400549, places=8)
        self.assertAlmostEqual(r["battery_kw"], 4.1469333943, places=8)

    def test_grade_is_ratio_not_degrees(self):
        r = road_load(self.p, 70, .08)
        self.assertAlmostEqual(r["motor_mechanical_kw"], 25.130097156, places=7)

    def test_rpm(self):
        self.assertAlmostEqual(motor_rpm(self.p, 90), 7673.541899, places=5)

    def test_range_sensitivity(self):
        self.assertEqual(range_estimate(self.p)["range_km"], 160)
        self.assertLess(range_estimate(self.p, 150)["range_km"], 150)
        self.assertAlmostEqual(range_estimate(self.p, energy_factor=.9)["range_km"], 144)

    def test_braking_matches_analytic_with_non_aligned_delay(self):
        for dt in [.01, .07]:
            r = braking(delay_s=.33, dt_s=dt)
            self.assertAlmostEqual(r["distance_m"], r["analytic_distance_m"], places=8)

    def test_low_adhesion(self):
        r = braking(mu=.35)
        self.assertAlmostEqual(r["deceleration_m_s2"], 3.4335)
        self.assertAlmostEqual(r["distance_m"], 32.2577158247, places=8)

    def test_stopped_vehicle(self):
        r = braking(speed_kmh=0)
        self.assertEqual((r["distance_m"], r["time_s"]), (0,0))

    def test_invalid_inputs_rejected(self):
        for kw in [dict(mu=0), dict(dt_s=0), dict(speed_kmh=-1)]:
            with self.assertRaises(ValueError):
                braking(**kw)
        self.p["usable_fraction"] = 80
        with self.assertRaises(ValueError):
            validate_config(self.p)

    def test_parallel_latency_and_surcharge(self):
        self.assertEqual(reaction_ms(), 250)
        self.assertEqual(reaction_ms(fusion=80), 305)

    def test_can_load(self):
        messages=json.loads((ROOT/"config/messages.json").read_text())
        self.assertAlmostEqual(bus_load(messages,500000), .065)

    def test_can_signed_endianness(self):
        self.assertEqual(encode_torque(10).hex(), "6400")
        self.assertAlmostEqual(decode_torque(encode_torque(-12.3)), -12.3)
        self.assertAlmostEqual(decode_torque(bytes.fromhex("0064")), 2560)

    def test_timeout_boundary_and_invalid_flag(self):
        self.assertTrue(monitor_command(30)["virtual_command_authorized"])
        self.assertFalse(monitor_command(31)["virtual_command_authorized"])
        self.assertFalse(monitor_command(10,valid=False)["virtual_command_authorized"])

if __name__ == "__main__":
    unittest.main()
