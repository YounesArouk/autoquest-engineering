"""Run from the repository root: py tools/run_ecity.py all --out reports/day18."""
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import html
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from ecity import __version__
from ecity.models import (validate_config, road_load, motor_rpm, range_estimate,
    braking, reaction_ms, bus_load, encode_torque, decode_torque, monitor_command)

def csv_file(path, rows):
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with path.open("w", encoding="utf-8-sig", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

def git_value(*args):
    try:
        return subprocess.check_output(["git", "-C", str(ROOT), *args],
            text=True, stderr=subprocess.DEVNULL).strip()
    except (OSError, subprocess.CalledProcessError):
        return None

def source_digest():
    digest = hashlib.sha256()
    for rel in ["ecity/__init__.py", "ecity/models.py", "tools/run_ecity.py"]:
        digest.update(rel.encode())
        digest.update((ROOT/rel).read_bytes())
    return digest.hexdigest()

def metadata(config_path, p, command):
    status = git_value("status", "--porcelain")
    return {"project": "E-City", "source_kind": "SYNTHETIC_MODEL",
        "model_version": __version__, "command": command,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_commit_before_run": git_value("rev-parse", "HEAD"),
        "working_tree_clean_before_run": status == "" if status is not None else None,
        "source_sha256": source_digest(),
        "config_file": config_path.name,
        "config_sha256": hashlib.sha256(config_path.read_bytes()).hexdigest(),
        "configuration": p,
        "limitations": "Constant efficiencies, simple road load and braking; no physical validation."}

def collect(command, p):
    tables, traces = {}, {}
    if command in ["all", "roadload"]:
        rows=[]
        for name,speed,grade in [("flat50",50,0),("flat90",90,0),("hill70",70,.08)]:
            r=road_load(p,speed,grade)
            r.update(scenario=name, motor_rpm=motor_rpm(p,speed),
                mechanical_margin_kw=p["continuous_motor_kw"]-r["motor_mechanical_kw"],
                scope="STATIONARY_ANALYSIS_THERMAL_OPEN")
            rows.append(r)
        tables["roadload"]=rows
    if command in ["all", "energy"]:
        rows=[]
        for label,wh,ef in [("reference",p["reference_wh_km"],1),
                ("high_consumption",150,1),("energy_minus_10pct",p["reference_wh_km"],.9)]:
            r=range_estimate(p,wh,ef)
            r.update(scenario=label,target_km=p["range_target_km"],
                margin_km=r["range_km"]-p["range_target_km"],
                scope="REFERENCE_ENERGY_NOT_MEASURED_RANGE")
            rows.append(r)
        tables["energy"]=rows
    if command in ["all", "braking"]:
        rows=[]
        for name,mu in [("nominal",.8),("low_adhesion",.35)]:
            r=braking(mu=mu)
            trace=r.pop("trace")
            traces[name]=trace
            r.update(scenario=name, mu=mu, initial_speed_kmh=50, delay_s=.30,
                comparison_limit_m=p["comparison_stop_m"],
                comparison="PASS" if r["distance_m"]<=p["comparison_stop_m"] else "FAIL",
                requirement_status=("PASS_ANALYSIS" if r["distance_m"]<=25 else "FAIL_ANALYSIS")
                    if name=="nominal" else "EXPLORATION_OUTSIDE_REQ04_NOMINAL_DOMAIN")
            rows.append(r)
        tables["braking"]=rows
    if command in ["all", "latency"]:
        rows=[]
        for name,camera,fusion in [("nominal",60,25),("slow_camera",100,25),("cpu_overload",60,80)]:
            total=reaction_ms(camera=camera,fusion=fusion)
            rows.append({"scenario":name,"camera_ms":camera,"radar_ms":40,
                "fusion_ms":fusion,"total_ms":total,"margin_ms":300-total,
                "comparison_300ms":"PASS" if total<=300 else "FAIL",
                "source_kind":"ALLOCATED_BUDGET_NOT_MEASUREMENT"})
        tables["latency"]=rows
    if command in ["all", "network"]:
        messages=json.loads((ROOT/"config/messages.json").read_text(encoding="utf-8-sig"))
        tables["messages"]=messages
        tables["network"]=[{"bitrate":p["bus_bitrate"],"load_pct":bus_load(messages,p["bus_bitrate"])*100,
            "torque_10nm_hex":encode_torque(10).hex(),
            "decoded_nm":decode_torque(encode_torque(10)),
            "scope":"ABSTRACT_MESSAGES_NO_REAL_CAN_BUS"}]
        tables["monitor"]=[dict(age_ms=age,valid=valid,**monitor_command(age,valid))
            for age,valid in [(10,True),(30,True),(31,True),(10,False)]]
    return tables,traces

def braking_svg(path, traces):
    w,h=800,380
    left,top,pw,ph=70,45,680,260
    tx=lambda t: left+t/5*pw
    ty=lambda v: top+ph-v/15*ph
    parts=[f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}">',
        '<rect width="800" height="380" fill="white"/>',
        '<g font-family="sans-serif" font-size="13" fill="#152e49">',
        '<text x="70" y="23">E-City: synthetic braking model</text>',
        '<text x="70" y="355">Time (s)</text><text x="6" y="35">m/s</text>']
    for i in range(6):
        x=tx(i)
        parts.extend([f'<path d="M{x},{top} V{top+ph}" stroke="#dce4ea"/>',
            f'<text x="{x}" y="{top+ph+23}">{i}</text>'])
    for v in [0,5,10,15]:
        y=ty(v)
        parts.extend([f'<path d="M{left},{y} H{left+pw}" stroke="#dce4ea"/>',
            f'<text x="38" y="{y+4}">{v}</text>'])
    for index,(name,trace) in enumerate(traces.items()):
        color=["#087e8b","#aa4242"][index%2]
        coords=" ".join(f"{tx(t):.3f},{ty(v):.3f}" for t,v,_ in trace)
        parts.append(f'<polyline points="{coords}" fill="none" stroke="{color}" stroke-width="2.5"/>')
        parts.append(f'<text x="{400+index*160}" y="23" fill="{color}">{html.escape(name)}</text>')
    parts.append('</g></svg>')
    path.write_text("\n".join(parts),encoding="utf-8")

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command",choices=["roadload","energy","braking","latency","network","all"])
    parser.add_argument("--config",default="config/reference.json")
    parser.add_argument("--out",default="reports/_scratch/latest")
    args=parser.parse_args()
    config_path=Path(args.config)
    if not config_path.is_absolute():config_path=ROOT/config_path
    p=validate_config(json.loads(config_path.read_text(encoding="utf-8-sig")))
    meta=metadata(config_path,p,args.command)
    tables,traces=collect(args.command,p)
    output=Path(args.out)
    if not output.is_absolute():output=ROOT/output
    output.mkdir(parents=True,exist_ok=True)
    for name,rows in tables.items():csv_file(output/(name+".csv"),rows)
    for name,trace in traces.items():
        csv_file(output/("trace_"+name+".csv"),
                 [dict(time_s=t,speed_m_s=v,distance_m=x) for t,v,x in trace])
    if traces:braking_svg(output/"braking.svg",traces)
    (output/"summary.json").write_text(json.dumps({"metadata":meta,"tables":tables},indent=2),encoding="utf-8")
    lines=["# E-City: synthetic report", "", "No physical validation is claimed.", "",
           "- Source SHA256: `"+meta["source_sha256"]+"`",
           "- Configuration SHA256: `"+meta["config_sha256"]+"`", ""]
    for name in tables:lines.append(f"- [{name}.csv]({name}.csv)")
    if traces:lines.extend(["", "![Synthetic braking](braking.svg)"])
    (output/"README.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("Synthetic report:",output)
    for name,rows in tables.items():print(name,":",len(rows),"row(s)")
    if traces:
        for r in tables["braking"]:print(r["scenario"],round(r["distance_m"],4),"m",r["requirement_status"])
    return 0

if __name__=="__main__":
    try:
        raise SystemExit(main())
    except (ValueError,KeyError,OSError,json.JSONDecodeError) as error:
        print("ERROR:",error,file=sys.stderr)
        raise SystemExit(2)
